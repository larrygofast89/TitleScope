# TitleScope 隐私政策 / Privacy Policy

最后更新 / Last updated: 2026-11-05

## 中文

**TitleScope 不收集、不存储、不传输任何个人数据到开发者或任何第三方服务器。**

### 插件做了什么

- 你在弹窗中输入的关键词，仅用于在你自己的浏览器里打开 Google 搜索页面，并读取页面上显示的结果数。
- 查询结果、你输入的关键词列表和选项（模式、地区、是否关闭个性化）会保存在你设备上浏览器的本地扩展存储（`chrome.storage.local`）中，用于在弹窗里展示，并在关闭弹窗或浏览器后继续保留。这些数据不会离开你的设备；点击「清空结果」可清除查询结果，卸载扩展会删除全部本地数据。
- 导出 CSV 时，文件在你的本地浏览器中生成并保存到你选择的位置，不经过任何服务器。

### 我们不做的事

- 不使用任何统计分析、广告或追踪工具
- 不向开发者或第三方服务器发送任何数据
- 不读取你的浏览历史、账号信息或其他网站的内容
- 不出售或共享任何用户数据

### 权限说明

| 权限 | 用途 |
|---|---|
| `tabs` | 创建、导航和关闭用于查询的后台标签页，读取该标签页地址以判断是否出现验证码，并在需要时将其切到前台 |
| `scripting` | 在 Google 搜索结果页内读取「结果数」文本 |
| `storage` | 在本地保存查询结果、关键词列表和选项，避免后台进程被回收时丢失 |
| `https://www.google.com/*` | 仅限在 Google 搜索页面上运行上述读取操作 |

### 第三方服务

插件会访问 `www.google.com` 以完成搜索。该访问由你的浏览器直接发出，适用 Google 自己的隐私政策；本插件与 Google 无关联，也不会获取你的 Google 账号信息。

### 政策变更

如本政策有变更，会在本页更新并修改上方日期。

### 联系方式

如有疑问，请联系：`<YOUR EMAIL>` 或在项目仓库提交 Issue。

---

## English

**TitleScope does not collect, store, or transmit any personal data to the developer or to any third-party server.**

### What the extension does

- Keywords you enter in the popup are used only to open Google Search pages in your own browser and read the result count shown on the page.
- Query results, the keyword list you typed, and your options (mode, region, personalization) are saved in the browser's local extension storage (`chrome.storage.local`) on your device, so they are shown in the popup and persist after closing the popup or the browser. This data never leaves your device; click "Clear results" to remove query results, and uninstalling the extension deletes all local data.
- When you export a CSV, the file is generated locally in your browser and saved wherever you choose. It does not pass through any server.

### What we do not do

- No analytics, advertising, or tracking tools
- No data sent to the developer or any third-party server
- No access to your browsing history, account information, or other websites' content
- No selling or sharing of user data

### Permissions

| Permission | Purpose |
|---|---|
| `tabs` | Create, navigate, and close the background tab used for queries; read that tab's URL to detect a CAPTCHA page; bring it to the front when needed |
| `scripting` | Read the "results" text on the Google Search results page |
| `storage` | Save results, the keyword list, and options locally so they are not lost when the background process is recycled |
| `https://www.google.com/*` | Limit the above reading to Google Search pages only |

### Third-party services

The extension visits `www.google.com` to perform searches. These requests are made directly by your browser and are subject to Google's own privacy policy. This extension is not affiliated with Google and does not access your Google account information.

### Changes

If this policy changes, this page and the date above will be updated.

### Contact

Questions: `<YOUR EMAIL>`, or open an issue in the project repository.
